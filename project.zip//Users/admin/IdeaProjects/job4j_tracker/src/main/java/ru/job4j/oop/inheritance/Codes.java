package ru.job4j.oop.inheritance;

public class Codes {
}
