package ru.job4j.prison;

public class Staff {
    private String name;
    private  int id;

    public void close(Convicted convicted) {
    }

    public void release(Convicted convicted) {
    }
}
