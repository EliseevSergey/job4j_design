package ru.job4j.strategy;

public interface Shape {
    String draw();
}
