package ru.job4j.oop.inheritance;

public class Task {
    private String content;

    public Task(String content) {
    this.content = content;
    }

    public String getContent() {
        return content;
    }
}
