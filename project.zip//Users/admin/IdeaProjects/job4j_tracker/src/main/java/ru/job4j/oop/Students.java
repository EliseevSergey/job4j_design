package ru.job4j.oop;

public class Students extends Object {
    public void diplom() {
        System.out.println("Write diplom");
    }
}
