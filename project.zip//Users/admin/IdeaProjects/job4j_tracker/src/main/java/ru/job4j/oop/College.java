package ru.job4j.oop;

public class College {
    public static void main(String[] args) {
        Freshman stepan = new Freshman();
        Students firstcourse = stepan;
        Object crowd = stepan;
    }
}
