package ru.job4j.tracker;

public interface Output {
    void println(Object obj);
}
