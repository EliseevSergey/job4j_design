package ru.job4j.oop;

public class Ball {
    public void escapeTry(Hare hare, Wolf wolf, Fox fox) {
    }
}
