package ru.job4j.oop.inheritance;

public class Diagnosis {
    private String diagnosis;

    public Diagnosis() {
    }

    public Diagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getDiagnosis() {
        return diagnosis;
    }
}
