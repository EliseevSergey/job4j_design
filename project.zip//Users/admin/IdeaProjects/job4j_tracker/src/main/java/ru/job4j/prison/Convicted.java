package ru.job4j.prison;

public class Convicted {
    private String name;
    private int number;
    private String reason;
    private int time;

    public void work() {
    }

    public void runaway() {
    }

    public void meetingWithLoyer() {
    }

    public static void main(String[] args) {
        Convicted tom = new Convicted();
    }
}
