package ru.job4j.oop;

public class Object {
    public void exist() {
        System.out.println(" exist");
    }
}
