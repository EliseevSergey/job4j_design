package ru.job4j.stream;

public class CheckGit {

}
