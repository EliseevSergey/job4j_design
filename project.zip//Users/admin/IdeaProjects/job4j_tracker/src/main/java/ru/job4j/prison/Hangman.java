package ru.job4j.prison;

public class Hangman extends Staff {
    final void switchOnElectricalChair(Convicted convicted) {
    }
}
