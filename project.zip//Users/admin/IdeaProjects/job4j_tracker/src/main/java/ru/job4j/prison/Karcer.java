package ru.job4j.prison;

public class Karcer {
    private Convicted[] carcer = new Convicted[99];

    public void makeLifeWorst(Convicted convicted) {
    }
}
