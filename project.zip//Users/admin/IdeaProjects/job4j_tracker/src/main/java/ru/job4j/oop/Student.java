package ru.job4j.oop;

public class Student {

    public void music(String lyrics) {
        System.out.println("I can sign a song : " + lyrics);
    }

    public static void main(String[] args) {
        Student petya = new Student();
        String song = "I believe, I can fly";
        String song2 = "We will rock you";
        petya.music(song);
        petya.music(song2);
    }
}
