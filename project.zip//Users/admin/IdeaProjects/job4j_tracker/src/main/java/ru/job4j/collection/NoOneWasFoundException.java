package ru.job4j.collection;

public class NoOneWasFoundException extends Exception {
    public NoOneWasFoundException(String message) {
        super(message);
    }
}
