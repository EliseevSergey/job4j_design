package ru.job4j.ooa;

public final class Aircraft {
    public final void printModel() {
        System.out.println("Метод выводит в консоль модель самолета.");
    }
}
