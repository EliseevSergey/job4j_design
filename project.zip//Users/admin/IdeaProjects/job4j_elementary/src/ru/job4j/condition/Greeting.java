package ru.job4j.condition;

public class Greeting {
    public static void main(String[] args) {
        String idea = " i like Java";
        System.out.println(idea);
        System.out.println(idea + " But I am a newbie");
        int year = 2020;
        System.out.println(idea + year);
    }
}
