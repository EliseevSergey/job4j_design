package ru.job4j;

public class LoopFor {
    public static void main(String[]ars) {
        for (int index = 5; index <= 10; index++) {
            System.out.println(index);
        }
    }
}
