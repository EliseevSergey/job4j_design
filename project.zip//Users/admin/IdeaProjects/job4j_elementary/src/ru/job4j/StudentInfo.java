package ru.job4j;

public class StudentInfo {
    public static void main(String[] args) {
        System.out.println("Sergey Eliseev");
        System.out.println("31.05.1988");
    }
}
