package ru.job4j;

public class Task42 {
    public static int func1(int x) {
        int k = x + 1;
        return k;
    }

    public static void main(String[] args) {
        int result = Task42.func1(100);
        System.out.println(result);
    }

}
