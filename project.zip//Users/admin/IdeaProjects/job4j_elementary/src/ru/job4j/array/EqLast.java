package ru.job4j.array;

public class EqLast {
    public static boolean tailCheck(int[] left, int[] right) {
        return left[left.length - 1] == right[right.length - 1];
    }
}
