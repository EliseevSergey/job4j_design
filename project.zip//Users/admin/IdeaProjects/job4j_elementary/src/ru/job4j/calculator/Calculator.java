package ru.job4j.calculator;

public class Calculator {
    private static int x = 5;

    public static int sum(int a, int b) {
        return a + b;
    }

    public static int minus(int m) {
        return m - x;
    }

    public int divide(int d) {
        return d / x;
    }

    public int multiply(int mltpl) {
        return x * mltpl;
    }

    public int sumAllOperation(int s) {
        return Calculator.sum(s, s) + Calculator.minus(s) + divide(s) + multiply(s);
    }

    public static void main(String[] args) {
        System.out.println("sum: " + Calculator.sum(5, 5)
        + ". minus: " + Calculator.minus(5));
        var calc = new Calculator();
        System.out.println("divide: " + calc.divide(5)
                + ". multiply: " + calc.multiply(5)
                + ". sumAll: " + calc.sumAllOperation(5));
    }
}