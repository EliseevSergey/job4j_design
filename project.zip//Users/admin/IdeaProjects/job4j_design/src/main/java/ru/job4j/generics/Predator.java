package ru.job4j.generics;

public class Predator extends Animal {
    public Predator(String name) {
        super(name);
    }
}
