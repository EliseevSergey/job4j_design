package ru.job4j.io.duplicates;

import java.util.Hashtable;

public class TryHashTbl {
    Hashtable<String, Long> tbl = new Hashtable<String, Long>();
    String text = "text";
    Long lng = Long.valueOf(444);

}
